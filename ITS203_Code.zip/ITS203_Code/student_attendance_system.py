import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime, date


# ============================================================
# DATABASE
# ============================================================

DB_NAME = "student_attendance.db"


def get_connection():
    return sqlite3.connect(DB_NAME)


def create_database():
    conn = get_connection()
    cursor = conn.cursor()

    # Users
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
    """)

    # Students
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            gender TEXT,
            email TEXT,
            phone TEXT,
            class_id INTEGER
        )
    """)

    # Teachers
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS teachers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_id TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            subject TEXT
        )
    """)

    # Classes
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS classes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_name TEXT NOT NULL,
            section TEXT NOT NULL,
            teacher_id INTEGER
        )
    """)

    # Attendance
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            class_id INTEGER,
            attendance_date TEXT NOT NULL,
            status TEXT NOT NULL,
            remarks TEXT,
            UNIQUE(student_id, attendance_date)
        )
    """)

    # Sample Admin
    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] == 0:
        cursor.execute("""
            INSERT INTO users (username, password, role)
            VALUES (?, ?, ?)
        """, ("admin", "admin123", "Administrator"))

    # Sample Teachers
    cursor.execute("SELECT COUNT(*) FROM teachers")
    if cursor.fetchone()[0] == 0:

        teachers = [
            ("T001", "John Smith", "john@example.com", "0300-1111111", "Computer Science"),
            ("T002", "Sarah Ahmed", "sarah@example.com", "0300-2222222", "Mathematics"),
            ("T003", "David Khan", "david@example.com", "0300-3333333", "Information Technology")
        ]

        cursor.executemany("""
            INSERT INTO teachers
            (teacher_id, name, email, phone, subject)
            VALUES (?, ?, ?, ?, ?)
        """, teachers)

    # Sample Classes
    cursor.execute("SELECT COUNT(*) FROM classes")
    if cursor.fetchone()[0] == 0:

        cursor.execute("SELECT id FROM teachers WHERE teacher_id='T001'")
        t1 = cursor.fetchone()[0]

        cursor.execute("SELECT id FROM teachers WHERE teacher_id='T002'")
        t2 = cursor.fetchone()[0]

        cursor.execute("SELECT id FROM teachers WHERE teacher_id='T003'")
        t3 = cursor.fetchone()[0]

        classes = [
            ("BS Computer Science", "A", t1),
            ("BS Information Technology", "A", t3),
            ("BS Mathematics", "A", t2)
        ]

        cursor.executemany("""
            INSERT INTO classes
            (class_name, section, teacher_id)
            VALUES (?, ?, ?)
        """, classes)

    # Sample Students
    cursor.execute("SELECT COUNT(*) FROM students")

    if cursor.fetchone()[0] == 0:

        cursor.execute("""
            SELECT id FROM classes
            WHERE class_name='BS Computer Science'
        """)
        cs_class = cursor.fetchone()[0]

        cursor.execute("""
            SELECT id FROM classes
            WHERE class_name='BS Information Technology'
        """)
        it_class = cursor.fetchone()[0]

        students = [
            ("S001", "Ali Hassan", "Male",
             "ali@example.com", "0300-1111111", cs_class),

            ("S002", "Ayesha Khan", "Female",
             "ayesha@example.com", "0300-2222222", cs_class),

            ("S003", "Ahmed Raza", "Male",
             "ahmed@example.com", "0300-3333333", cs_class),

            ("S004", "Fatima Noor", "Female",
             "fatima@example.com", "0300-4444444", it_class),

            ("S005", "Usman Ali", "Male",
             "usman@example.com", "0300-5555555", it_class),

            ("S006", "Hina Malik", "Female",
             "hina@example.com", "0300-6666666", it_class)
        ]

        cursor.executemany("""
            INSERT INTO students
            (student_id, name, gender, email, phone, class_id)
            VALUES (?, ?, ?, ?, ?, ?)
        """, students)

    # Sample Attendance
    cursor.execute("SELECT COUNT(*) FROM attendance")

    if cursor.fetchone()[0] == 0:

        cursor.execute("SELECT id FROM students WHERE student_id='S001'")
        s1 = cursor.fetchone()[0]

        cursor.execute("SELECT id FROM students WHERE student_id='S002'")
        s2 = cursor.fetchone()[0]

        cursor.execute("SELECT id FROM students WHERE student_id='S003'")
        s3 = cursor.fetchone()[0]

        cursor.execute("SELECT id FROM students WHERE student_id='S004'")
        s4 = cursor.fetchone()[0]

        cursor.execute("SELECT id FROM students WHERE student_id='S005'")
        s5 = cursor.fetchone()[0]

        cursor.execute("SELECT id FROM students WHERE student_id='S006'")
        s6 = cursor.fetchone()[0]

        attendance_data = [
            (s1, cs_class, "2026-09-15", "Present", ""),
            (s2, cs_class, "2026-09-15", "Present", ""),
            (s3, cs_class, "2026-09-15", "Absent", "Sick"),
            (s4, it_class, "2026-09-15", "Present", ""),
            (s5, it_class, "2026-09-15", "Absent", "No reason"),
            (s6, it_class, "2026-09-15", "Present", ""),

            (s1, cs_class, "2026-09-16", "Present", ""),
            (s2, cs_class, "2026-09-16", "Absent", "Medical"),
            (s3, cs_class, "2026-09-16", "Present", ""),
            (s4, it_class, "2026-09-16", "Present", ""),
            (s5, it_class, "2026-09-16", "Present", ""),
            (s6, it_class, "2026-09-16", "Absent", "Personal")
        ]

        cursor.executemany("""
            INSERT INTO attendance
            (student_id, class_id, attendance_date, status, remarks)
            VALUES (?, ?, ?, ?, ?)
        """, attendance_data)

    conn.commit()
    conn.close()


# ============================================================
# LOGIN WINDOW
# ============================================================

class LoginWindow:

    def __init__(self, root):

        self.root = root

        self.root.title("Student Attendance Management System")
        self.root.geometry("500x400")
        self.root.resizable(False, False)

        title = tk.Label(
            root,
            text="Student Attendance\nManagement System",
            font=("Arial", 22, "bold")
        )

        title.pack(pady=35)

        frame = tk.Frame(root)
        frame.pack()

        tk.Label(
            frame,
            text="Username",
            font=("Arial", 12)
        ).grid(row=0, column=0, padx=10, pady=10)

        self.username = tk.Entry(
            frame,
            font=("Arial", 12),
            width=25
        )

        self.username.grid(row=0, column=1)

        tk.Label(
            frame,
            text="Password",
            font=("Arial", 12)
        ).grid(row=1, column=0, padx=10, pady=10)

        self.password = tk.Entry(
            frame,
            font=("Arial", 12),
            width=25,
            show="*"
        )

        self.password.grid(row=1, column=1)

        login_button = tk.Button(
            root,
            text="LOGIN",
            width=20,
            height=2,
            command=self.login
        )

        login_button.pack(pady=25)

        tk.Label(
            root,
            text="Sample Login: admin / admin123",
            fg="gray"
        ).pack()

    def login(self):

        username = self.username.get()
        password = self.password.get()

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT username, role
            FROM users
            WHERE username=? AND password=?
        """, (username, password))

        user = cursor.fetchone()

        conn.close()

        if user:

            self.root.destroy()

            main_root = tk.Tk()
            AttendanceSystem(main_root, user[0], user[1])
            main_root.mainloop()

        else:

            messagebox.showerror(
                "Login Failed",
                "Invalid username or password."
            )


# ============================================================
# MAIN SYSTEM
# ============================================================

class AttendanceSystem:

    def __init__(self, root, username, role):

        self.root = root
        self.username = username
        self.role = role

        self.root.title(
            "Student Attendance Management System"
        )

        self.root.geometry("1200x700")

        self.create_header()
        self.create_menu()
        self.create_dashboard()

    # --------------------------------------------------------
    # HEADER
    # --------------------------------------------------------

    def create_header(self):

        header = tk.Frame(
            self.root,
            bg="#1f4e78",
            height=70
        )

        header.pack(fill="x")

        tk.Label(
            header,
            text="Student Attendance Management System",
            bg="#1f4e78",
            fg="white",
            font=("Arial", 20, "bold")
        ).pack(side="left", padx=20, pady=18)

        tk.Label(
            header,
            text=f"User: {self.username}",
            bg="#1f4e78",
            fg="white",
            font=("Arial", 11)
        ).pack(side="right", padx=20)

    # --------------------------------------------------------
    # MENU
    # --------------------------------------------------------

    def create_menu(self):

        menu = tk.Frame(self.root, bg="#eeeeee")
        menu.pack(fill="x")

        buttons = [
            ("Dashboard", self.create_dashboard),
            ("Students", self.student_management),
            ("Teachers", self.teacher_management),
            ("Classes", self.class_management),
            ("Attendance", self.attendance_recording),
            ("View Attendance", self.attendance_view),
            ("Reports", self.attendance_reports),
            ("Notifications", self.absence_notifications)
        ]

        for text, command in buttons:

            tk.Button(
                menu,
                text=text,
                command=command,
                padx=10,
                pady=8
            ).pack(side="left", padx=2, pady=5)

    # --------------------------------------------------------
    # CLEAR CONTENT
    # --------------------------------------------------------

    def clear_content(self):

        for widget in self.content.winfo_children():
            widget.destroy()

    # --------------------------------------------------------
    # DASHBOARD
    # --------------------------------------------------------

    def create_dashboard(self):

        if hasattr(self, "content"):
            self.content.destroy()

        self.content = tk.Frame(self.root)
        self.content.pack(fill="both", expand=True)

        tk.Label(
            self.content,
            text="Dashboard",
            font=("Arial", 22, "bold")
        ).pack(pady=30)

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT COUNT(*) FROM students")
        students = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM teachers")
        teachers = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM classes")
        classes = cursor.fetchone()[0]

        cursor.execute("""
            SELECT COUNT(*)
            FROM attendance
            WHERE status='Absent'
        """)

        absences = cursor.fetchone()[0]

        conn.close()

        frame = tk.Frame(self.content)
        frame.pack()

        self.dashboard_card(
            frame,
            "Students",
            students,
            0
        )

        self.dashboard_card(
            frame,
            "Teachers",
            teachers,
            1
        )

        self.dashboard_card(
            frame,
            "Classes",
            classes,
            2
        )

        self.dashboard_card(
            frame,
            "Absences",
            absences,
            3
        )

        tk.Label(
            self.content,
            text="Use the navigation buttons above to manage attendance.",
            font=("Arial", 12)
        ).pack(pady=40)

    def dashboard_card(self, parent, title, value, column):

        card = tk.Frame(
            parent,
            relief="ridge",
            borderwidth=2,
            width=200,
            height=120
        )

        card.grid(
            row=0,
            column=column,
            padx=15,
            pady=20
        )

        tk.Label(
            card,
            text=title,
            font=("Arial", 12, "bold")
        ).pack(pady=10)

        tk.Label(
            card,
            text=str(value),
            font=("Arial", 24, "bold")
        ).pack()

    # ========================================================
    # STUDENT MANAGEMENT
    # ========================================================

    def student_management(self):

        self.clear_content()

        tk.Label(
            self.content,
            text="Student Management",
            font=("Arial", 20, "bold")
        ).pack(pady=10)

        form = tk.Frame(self.content)
        form.pack(pady=5)

        labels = [
            "Student ID",
            "Name",
            "Gender",
            "Email",
            "Phone"
        ]

        self.student_entries = []

        for i, label in enumerate(labels):

            tk.Label(
                form,
                text=label
            ).grid(row=i, column=0, padx=5, pady=5)

            entry = tk.Entry(
                form,
                width=30
            )

            entry.grid(row=i, column=1, padx=5)

            self.student_entries.append(entry)

        tk.Button(
            form,
            text="Add Student",
            command=self.add_student
        ).grid(row=5, column=0, columnspan=2, pady=10)

        self.student_table = ttk.Treeview(
            self.content,
            columns=(
                "ID",
                "Student ID",
                "Name",
                "Gender",
                "Email",
                "Phone"
            ),
            show="headings"
        )

        for column in self.student_table["columns"]:
            self.student_table.heading(column, text=column)
            self.student_table.column(column, width=130)

        self.student_table.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=10
        )

        self.load_students()

    def add_student(self):

        values = [
            entry.get()
            for entry in self.student_entries
        ]

        if not values[0] or not values[1]:
            messagebox.showwarning(
                "Required",
                "Student ID and Name are required."
            )
            return

        conn = get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT id FROM classes LIMIT 1
            """)

            class_row = cursor.fetchone()

            class_id = class_row[0] if class_row else None

            cursor.execute("""
                INSERT INTO students
                (student_id, name, gender, email, phone, class_id)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (*values, class_id))

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Student added successfully."
            )

            self.student_management()

        except sqlite3.IntegrityError:

            messagebox.showerror(
                "Error",
                "Student ID already exists."
            )

        finally:

            conn.close()

    def load_students(self):

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, student_id, name,
                   gender, email, phone
            FROM students
        """)

        rows = cursor.fetchall()

        conn.close()

        for row in rows:

            self.student_table.insert(
                "",
                "end",
                values=row
            )

    # ========================================================
    # TEACHER MANAGEMENT
    # ========================================================

    def teacher_management(self):

        self.clear_content()

        tk.Label(
            self.content,
            text="Teacher Management",
            font=("Arial", 20, "bold")
        ).pack(pady=15)

        form = tk.Frame(self.content)
        form.pack()

        fields = [
            "Teacher ID",
            "Name",
            "Email",
            "Phone",
            "Subject"
        ]

        self.teacher_entries = []

        for i, field in enumerate(fields):

            tk.Label(
                form,
                text=field
            ).grid(row=i, column=0, padx=10, pady=5)

            entry = tk.Entry(
                form,
                width=30
            )

            entry.grid(row=i, column=1)

            self.teacher_entries.append(entry)

        tk.Button(
            form,
            text="Add Teacher",
            command=self.add_teacher
        ).grid(
            row=5,
            column=0,
            columnspan=2,
            pady=10
        )

        self.teacher_table = ttk.Treeview(
            self.content,
            columns=(
                "ID",
                "Teacher ID",
                "Name",
                "Email",
                "Phone",
                "Subject"
            ),
            show="headings"
        )

        for column in self.teacher_table["columns"]:
            self.teacher_table.heading(
                column,
                text=column
            )

        self.teacher_table.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=10
        )

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, teacher_id, name,
                   email, phone, subject
            FROM teachers
        """)

        rows = cursor.fetchall()

        conn.close()

        for row in rows:
            self.teacher_table.insert(
                "",
                "end",
                values=row
            )

    def add_teacher(self):

        values = [
            e.get()
            for e in self.teacher_entries
        ]

        if not values[0] or not values[1]:
            messagebox.showwarning(
                "Required",
                "Teacher ID and Name are required."
            )
            return

        conn = get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                INSERT INTO teachers
                (teacher_id, name, email, phone, subject)
                VALUES (?, ?, ?, ?, ?)
            """, values)

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Teacher added successfully."
            )

            self.teacher_management()

        except sqlite3.IntegrityError:

            messagebox.showerror(
                "Error",
                "Teacher ID already exists."
            )

        finally:

            conn.close()

    # ========================================================
    # CLASS MANAGEMENT
    # ========================================================

    def class_management(self):

        self.clear_content()

        tk.Label(
            self.content,
            text="Class Management",
            font=("Arial", 20, "bold")
        ).pack(pady=15)

        form = tk.Frame(self.content)
        form.pack()

        tk.Label(
            form,
            text="Class Name"
        ).grid(row=0, column=0, padx=10)

        self.class_name = tk.Entry(
            form,
            width=30
        )

        self.class_name.grid(row=0, column=1)

        tk.Label(
            form,
            text="Section"
        ).grid(row=1, column=0, padx=10)

        self.section = tk.Entry(
            form,
            width=30
        )

        self.section.grid(row=1, column=1)

        tk.Button(
            form,
            text="Add Class",
            command=self.add_class
        ).grid(
            row=2,
            column=0,
            columnspan=2,
            pady=10
        )

        self.class_table = ttk.Treeview(
            self.content,
            columns=(
                "ID",
                "Class",
                "Section",
                "Teacher"
            ),
            show="headings"
        )

        for column in self.class_table["columns"]:
            self.class_table.heading(
                column,
                text=column
            )

        self.class_table.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=10
        )

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT classes.id,
                   classes.class_name,
                   classes.section,
                   teachers.name
            FROM classes
            LEFT JOIN teachers
            ON classes.teacher_id = teachers.id
        """)

        rows = cursor.fetchall()

        conn.close()

        for row in rows:

            self.class_table.insert(
                "",
                "end",
                values=row
            )

    def add_class(self):

        name = self.class_name.get()
        section = self.section.get()

        if not name or not section:

            messagebox.showwarning(
                "Required",
                "Class name and section are required."
            )

            return

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id FROM teachers LIMIT 1
        """)

        teacher = cursor.fetchone()

        teacher_id = teacher[0] if teacher else None

        cursor.execute("""
            INSERT INTO classes
            (class_name, section, teacher_id)
            VALUES (?, ?, ?)
        """, (name, section, teacher_id))

        conn.commit()
        conn.close()

        messagebox.showinfo(
            "Success",
            "Class added successfully."
        )

        self.class_management()

    # ========================================================
    # ATTENDANCE RECORDING
    # ========================================================

    def attendance_recording(self):

        self.clear_content()

        tk.Label(
            self.content,
            text="Attendance Recording",
            font=("Arial", 20, "bold")
        ).pack(pady=10)

        top = tk.Frame(self.content)
        top.pack(pady=5)

        tk.Label(
            top,
            text="Date:"
        ).pack(side="left")

        self.attendance_date = tk.Entry(
            top,
            width=15
        )

        self.attendance_date.insert(
            0,
            date.today().strftime("%Y-%m-%d")
        )

        self.attendance_date.pack(
            side="left",
            padx=10
        )

        self.attendance_table = ttk.Treeview(
            self.content,
            columns=(
                "ID",
                "Student ID",
                "Name",
                "Status"
            ),
            show="headings"
        )

        for column in self.attendance_table["columns"]:
            self.attendance_table.heading(
                column,
                text=column
            )

        self.attendance_table.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=10
        )

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT id, student_id, name
            FROM students
        """)

        students = cursor.fetchall()

        conn.close()

        for student in students:

            self.attendance_table.insert(
                "",
                "end",
                values=(
                    student[0],
                    student[1],
                    student[2],
                    "Present"
                )
            )

        tk.Button(
            self.content,
            text="Mark Selected as Absent",
            command=self.mark_absent
        ).pack(side="left", padx=30, pady=10)

        tk.Button(
            self.content,
            text="Save Attendance",
            command=self.save_attendance
        ).pack(side="right", padx=30, pady=10)

    def mark_absent(self):

        selected = self.attendance_table.selection()

        for item in selected:

            values = list(
                self.attendance_table.item(
                    item,
                    "values"
                )
            )

            values[3] = "Absent"

            self.attendance_table.item(
                item,
                values=values
            )

    def save_attendance(self):

        attendance_date = self.attendance_date.get()

        conn = get_connection()
        cursor = conn.cursor()

        for item in self.attendance_table.get_children():

            values = self.attendance_table.item(
                item,
                "values"
            )

            student_id = values[0]
            status = values[3]

            cursor.execute("""
                SELECT class_id
                FROM students
                WHERE id=?
            """, (student_id,))

            result = cursor.fetchone()

            class_id = result[0] if result else None

            cursor.execute("""
                INSERT OR REPLACE INTO attendance
                (student_id, class_id,
                 attendance_date, status, remarks)
                VALUES (?, ?, ?, ?, ?)
            """, (
                student_id,
                class_id,
                attendance_date,
                status,
                ""
            ))

        conn.commit()
        conn.close()

        messagebox.showinfo(
            "Success",
            "Attendance saved successfully."
        )

    # ========================================================
    # VIEW ATTENDANCE
    # ========================================================

    def attendance_view(self):

        self.clear_content()

        tk.Label(
            self.content,
            text="Attendance Viewing and Search",
            font=("Arial", 20, "bold")
        ).pack(pady=10)

        search_frame = tk.Frame(self.content)
        search_frame.pack()

        tk.Label(
            search_frame,
            text="Search:"
        ).pack(side="left")

        self.search_entry = tk.Entry(
            search_frame,
            width=30
        )

        self.search_entry.pack(
            side="left",
            padx=10
        )

        tk.Button(
            search_frame,
            text="Search",
            command=self.search_attendance
        ).pack(side="left")

        tk.Button(
            search_frame,
            text="Show All",
            command=self.load_attendance
        ).pack(side="left", padx=5)

        self.view_table = ttk.Treeview(
            self.content,
            columns=(
                "ID",
                "Student ID",
                "Student",
                "Date",
                "Status",
                "Remarks"
            ),
            show="headings"
        )

        for column in self.view_table["columns"]:

            self.view_table.heading(
                column,
                text=column
            )

            self.view_table.column(
                column,
                width=150
            )

        self.view_table.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=20
        )

        self.load_attendance()

    def load_attendance(self):

        for item in self.view_table.get_children():
            self.view_table.delete(item)

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT attendance.id,
                   students.student_id,
                   students.name,
                   attendance.attendance_date,
                   attendance.status,
                   attendance.remarks
            FROM attendance
            JOIN students
            ON attendance.student_id=students.id
            ORDER BY attendance.attendance_date DESC
        """)

        rows = cursor.fetchall()

        conn.close()

        for row in rows:

            self.view_table.insert(
                "",
                "end",
                values=row
            )

    def search_attendance(self):

        keyword = self.search_entry.get()

        for item in self.view_table.get_children():
            self.view_table.delete(item)

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT attendance.id,
                   students.student_id,
                   students.name,
                   attendance.attendance_date,
                   attendance.status,
                   attendance.remarks
            FROM attendance
            JOIN students
            ON attendance.student_id=students.id
            WHERE students.name LIKE ?
               OR students.student_id LIKE ?
               OR attendance.status LIKE ?
               OR attendance.attendance_date LIKE ?
        """, (
            f"%{keyword}%",
            f"%{keyword}%",
            f"%{keyword}%",
            f"%{keyword}%"
        ))

        rows = cursor.fetchall()

        conn.close()

        for row in rows:

            self.view_table.insert(
                "",
                "end",
                values=row
            )

    # ========================================================
    # REPORTS
    # ========================================================

    def attendance_reports(self):

        self.clear_content()

        tk.Label(
            self.content,
            text="Attendance Reports",
            font=("Arial", 20, "bold")
        ).pack(pady=15)

        report_table = ttk.Treeview(
            self.content,
            columns=(
                "Student ID",
                "Student",
                "Present",
                "Absent",
                "Total",
                "Percentage"
            ),
            show="headings"
        )

        for column in report_table["columns"]:

            report_table.heading(
                column,
                text=column
            )

            report_table.column(
                column,
                width=150
            )

        report_table.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=20
        )

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                students.student_id,
                students.name,

                SUM(
                    CASE
                    WHEN attendance.status='Present'
                    THEN 1 ELSE 0
                    END
                ) AS present_count,

                SUM(
                    CASE
                    WHEN attendance.status='Absent'
                    THEN 1 ELSE 0
                    END
                ) AS absent_count,

                COUNT(attendance.id) AS total

            FROM students

            LEFT JOIN attendance
            ON students.id=attendance.student_id

            GROUP BY students.id
        """)

        rows = cursor.fetchall()

        conn.close()

        for row in rows:

            present = row[2] or 0
            absent = row[3] or 0
            total = row[4] or 0

            percentage = (
                (present / total) * 100
                if total > 0
                else 0
            )

            report_table.insert(
                "",
                "end",
                values=(
                    row[0],
                    row[1],
                    present,
                    absent,
                    total,
                    f"{percentage:.2f}%"
                )
            )

    # ========================================================
    # ABSENCE NOTIFICATIONS
    # ========================================================

    def absence_notifications(self):

        self.clear_content()

        tk.Label(
            self.content,
            text="Absence Notifications",
            font=("Arial", 20, "bold")
        ).pack(pady=15)

        notification_table = ttk.Treeview(
            self.content,
            columns=(
                "Student ID",
                "Student",
                "Email",
                "Date",
                "Status"
            ),
            show="headings"
        )

        for column in notification_table["columns"]:

            notification_table.heading(
                column,
                text=column
            )

            notification_table.column(
                column,
                width=170
            )

        notification_table.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=20
        )

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT students.student_id,
                   students.name,
                   students.email,
                   attendance.attendance_date,
                   attendance.status

            FROM attendance

            JOIN students
            ON attendance.student_id=students.id

            WHERE attendance.status='Absent'

            ORDER BY attendance.attendance_date DESC
        """)

        rows = cursor.fetchall()

        conn.close()

        for row in rows:

            notification_table.insert(
                "",
                "end",
                values=row
            )

        tk.Label(
            self.content,
            text="The list above identifies students who require absence notification.",
            font=("Arial", 11)
        ).pack(pady=10)


# ============================================================
# START APPLICATION
# ============================================================

if __name__ == "__main__":

    create_database()

    root = tk.Tk()

    LoginWindow(root)

    root.mainloop()